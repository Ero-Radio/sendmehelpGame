require "BaseO"
require "Rope"
require "Antena"
require "EPost"
require "Pulse"
function love.load()
	love.window.setTitle("Send me help")
	sWidth = love.graphics.getWidth()
	sHeight = love.graphics.getHeight()
	teste = {}
	
	teste[1] = Antena.new(200, 200, 0)
	teste[2] = Antena.new(400, 300, 0)
	--teste[3] = Rope.new(5, 100, 100)

	pulse = Pulse.new(teste)
	 
end

function love.draw()
	if pulse.step > #pulse.objects_list then
		love.graphics.printf("Cachaça carai", 200, 200, 300, "center")
	end
	for i=1,#teste do
		teste[i]:draw()
	end

	pulse:draw()
	love.graphics.print(pulse.step, 10, 10)
	love.graphics.print("carai", 10, 20)
	love.graphics.print(pulse.stepInside, 10, 30)


end

function love.update(dt)
	for i=1,#teste do
		teste[i]:update(dt)
	end

	pulse:update(dt)

end

function love.mousereleased(x, y, button, istouch)
	pulse:resetSteps()
end

function dist(x1, y1, x2, y2)
	d = math.sqrt(math.pow(x1-x2, 2) + math.pow(y1-y2, 2))
	if d < 1 then
		d = 1
	end
	return d
end